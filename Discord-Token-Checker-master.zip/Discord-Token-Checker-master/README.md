## Discord Token Checker

Discord Token Checker for checking discord tokens!

## Installation

Install NodeJS: https://nodejs.org/en/download/

Run this command in console

```
npm install
```

## Tokens

Put your tokens inside of tokens.txt in this format

```
MzI1MTU3ODA5MjExNTcyMjI1.DOQYbA.vnBfE7DtN2zxZW6Ohw_POto6npA
MTYzODM3OTQ3OTY2MTI4MTI4.DOQApA.q-RZqUVpg2drGqpSjatcZf0EJZY
Mjc2MDY1OTc4MzM1NjI1MjE2.DNTGNw.cbNgca_1_9mJ9dal7bdnNkLcPxE
```

## Starting

Run this command

```
node index.js
```

## Usage

When the program has started it will check tokens as fast as possible!
To check the tokens go into the output folder.

Feel free to change the timeout in config.json to fit your needs!

## Contact

Telegram Chat: https://t.me/DiscordTools

## Donate

Bitcoin: 1JKtC7rQNo23iA9p35XaovetKvs5RDF1S
